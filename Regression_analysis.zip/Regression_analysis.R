## ----setup, include=FALSE--------------------------------------------------------------------------------------------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)
library(knitr)
library(ggplot2)

## ----2. Load the data------------------------------------------------------------------------------------------------------------------------------------------
rm(list=ls()) 
set.seed(1)
data <- load("DATA.RData")
FunctionLSS = function(y,X) 
{
  # Number of observations and column dimension of X
  N         = nrow(X)
  K         = ncol(X)
  # OLS estimates, predictions, residuals 
  B_hat     = solve(t(X)%*%X)%*%t(X)%*%y
  y_hat     = as.vector(X%*%B_hat)
  u_hat     = as.vector(y-y_hat)
  # Inference
  sigma_hat = 1/(N-K)*drop(t(u_hat)%*%u_hat)
  B_hat_VCE = sigma_hat*solve(t(X)%*%X)
  B_hat_SEE = sqrt(diag(B_hat_VCE))
  return(list(N=N,K=K,B_hat=B_hat,y_hat=y_hat,u_hat=u_hat,sigma_hat=sigma_hat,B_hat_VCE=B_hat_VCE,B_hat_SEE=B_hat_SEE))
}
N = length(age)
x_0 = rep(1,N) 
X = cbind(x_0,age,black,educ)
y = lwage
results = FunctionLSS(y,X)
B_hat = results["B_hat"] # or results$B_hat
B_hat_SEE = results["B_hat_SEE"]
B_hat
helllo = results$B_hat
#
FunctionLSS_2SLS = function(y,X,Z) 
{
  # Number of observations and column dimension of X
  N         = nrow(X)
  K         = ncol(X)
  #############################################
  ## Stage one (_so) of 2SLS
  # Estimates, predictions, residuals
  B_hat_so            = solve(t(Z)%*%Z)%*%t(Z)%*%X
  X_hat_so            = Z%*%B_hat_so
  
  #############################################
  ## Stage two (_st) of 2SLS
  # Estimates, predictions, residuals
  B_hat_st            = solve(t(X_hat_so)%*%X_hat_so)%*%t(X_hat_so)%*%y
  y_hat_st            = as.vector(X%*%B_hat_st)
  u_hat_st            = as.vector(y-y_hat_st)
  # The variance-covariance matrix of the OLS estimator
  s2_st               = 1/N * drop(t(u_hat_st)%*%u_hat_st)
  B_hat_VCE_st        = s2_st * solve(t(X_hat_so)%*%X_hat_so)
  B_hat_SEE_st         = sqrt(diag(B_hat_VCE_st))
  
  return(list(N=N,K=K,B_hat_so=B_hat_so,X_hat_so=X_hat_so,
              B_hat_st=B_hat_st,y_hat_st=y_hat_st,u_hat_st=u_hat_st,
              B_hat_VCE_st=B_hat_VCE_st,B_hat_SEE_st=B_hat_SEE_st)) 
}
Z = cbind(x_0,age,black,fatheduc,motheduc)
RES_2SLS = FunctionLSS_2SLS(y,X,Z) 
B_hat_2sls1 = RES_2SLS["B_hat_st"]
B_hat_SEE_2sls = RES_2SLS["B_hat_SEE_st"]
B_hat_2sls1
B_hat_SEE_2sls
residuals_ = X-RES_2SLS$X_hat_so
predictions = RES_2SLS$X_hat_so
education_prediction = as.vector(predictions[,4])
new_X = cbind(x_0,age,black,education_prediction)
OLSresidual = FunctionLSS(y,new_X)



tinytex::install_tinytex()

GMM_B_hat = function(y,X,Z,W) {
  B_hat = solve(t(X) %*% Z %*% W %*% t(Z) %*% X) %*% (t(X) %*% Z %*% W %*% t(Z) %*% y)
  return(B_hat)
}
rep.col <- function(x, n){
  matrix(rep(x, each = n), ncol = n, byrow = TRUE)
}

FunctionLSS_GMM = function(y,X,Z) 
{
  # Number of observations and column dimension of X
  N         = nrow(X)
  K         = ncol(X)
  L         = ncol(Z)
  ###########################################
  ## First iteration with W=I
  W1          = diag(L)
  B_hat_fi    = GMM_B_hat(y,X,Z,W1)
  
  ###########################################
  ## Second iteration
  # Get optimal weighting matrix
  e = rep.col(y - X %*% B_hat_fi, L)
  Omega = t(Z * e) %*% (Z * e) 
  # Coefficient stimates based on optimal weighting matrix
  B_hat     = GMM_B_hat(y,X,Z,solve(Omega))
  # Asymptotic variance and standard errors
  u_hat     = as.vector(y - X %*% B_hat )
  Q         = t(Z) %*% X 
  B_hat_VCE = solve(t(Q)%*%solve(Omega)%*%Q)
  B_hat_SEE = sqrt(diag(B_hat_VCE))
  
  return(list(N=N,K=K,B_hat=B_hat,B_hat_VCE=B_hat_VCE,B_hat_SEE=B_hat_SEE)) 
}


## ----13. Efficient GMM estimation------------------------------------------------------------------------------------------------------------------------------
RES_GMM = FunctionLSS_GMM(y,X,Z)
B_hat_GMM = RES_GMM$B_hat
B_hat_GMM_SEE = RES_GMM$B_hat_SEE
B_hat_SEE 
B_hat 
B_hat_2sls1
B_hat_SEE_2sls
B_hat_GMM
B_hat_GMM_SEE
diff = RES_2SLS$B_hat_st - RES_GMM$B_hat
diff  
RES_2SLS$B_hat_SEE_st - RES_GMM$B_hat_SEE > 0 
  
  
  
  